/**
 * 
 */
package com.peerdroid.res;

/**
 * @author linghu
 *
 */
public class Video extends Resource {

	/* (non-Javadoc)
	 * @see peerdroid.sample.res.Resource#getBytes()
	 */
	@Override
	byte[] getBytes() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see peerdroid.sample.res.Resource#getResource(byte[])
	 */
	@Override
	Resource getResource(byte[] bytes) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see peerdroid.sample.res.Resource#getResourceSize()
	 */
	@Override
	int getResourceSize() {
		// TODO Auto-generated method stub
		return 0;
	}

	/* (non-Javadoc)
	 * @see peerdroid.sample.res.Resource#getResourceType()
	 */
	@Override
	int getResourceType() {
		// TODO Auto-generated method stub
		return 0;
	}

}
