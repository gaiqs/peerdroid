/**
 * 
 */
package com.peerdroid.tools;

/**
 * @author linghu
 *
 */
public class Constant {

	/**
	 * rdv list
	 */
	public static String RDVLIST = "http://www-scf.usc.edu/~lingh/docs/rdvlist.txt"; //ling's rdv list;
	
	/**
	 * name of the peer
	 */
	public static String INSTNAME = "mobile" ;
}
